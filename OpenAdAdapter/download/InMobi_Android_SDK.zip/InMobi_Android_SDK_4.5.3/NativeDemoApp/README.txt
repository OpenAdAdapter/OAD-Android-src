* This DemoApp is supported for tablets from Android 4.0 and above.
* This DemoApp is supported for Smart phones from Android 2.2 and above.


